# Project 0

## Instructions on how to compile the code

1. In the command line, navigate to the src directory by running `cd <path to the src directory>`

2. Compile the Assembler.java file by running `javac Assembler.java` (or run with path to the ReadFile.java ignoring step1)

## Instructions on how to run the code

1. Inside the src directory, run the executable file `Assembler.class` by running `java Assembler <filename.in>`, 
  where <filename.in> is a path to the input file

## What works and what doesn't work

Everything works.