What works and what doesn't:

- Everything works