Everything works

Compiling: 
'''
javac VirtualMachineTranslator.java
'''

Executution:
'''
java VirtualMachineTranslator <file path.vm>
'''